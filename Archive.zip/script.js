function toggleMenu() {
    const menu = document.querySelector(".menu-links");
    const icon = document.querySelector(".hamburger-icon");
    menu.classList.toggle("open");
    icon.classList.toggle("open");
}

function downloadCV() {
    const cvUrl ="/assets/DaveBryan_Tamakloe_CV.pd"
}